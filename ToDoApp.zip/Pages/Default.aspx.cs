using System;
public partial class Pages_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) {}

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(txtTask.Text))
        {
            listTasks.Items.Add(txtTask.Text);
            txtTask.Text = string.Empty;
        }
    }
}